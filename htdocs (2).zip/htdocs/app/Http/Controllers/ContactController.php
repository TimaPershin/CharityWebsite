<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactMessageMail;


class ContactController extends Controller
{
    public function create()
    {
        return view('pages.contacts.create');
    }

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:100',
        'email' => 'required|email',
        'message' => 'required|string|max:2000'
    ]);
    $data = $request->only(['name', 'email', 'message']);

    // Отправка письма
    Mail::to('your_admin_email@example.com')->send(new ContactMessageMail($data));

    ContactMessage::create($request->only(['name', 'email', 'message']));

    return redirect()->back()->with('success', 'Ваше сообщение отправлено!');
}
}
