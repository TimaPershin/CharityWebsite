<?php

namespace App\Http\Controllers;

use App\Models\Donation;
use Illuminate\Http\Request;

class DonationController extends Controller
{
public function store(Request $request)
{
    $request->validate([
        'amount' => 'required|numeric|min:1',
        'project_id' => 'required|exists:projects,id',
        'message' => 'nullable|string|max:1000',
    ]);

    $user = auth()->user();

    Donation::create([
        'user_id' => $user->id,
        'donor_name' => $user->name,
        'donor_email' => $user->email,
        'amount' => $request->input('amount'),
        'project_id' => $request->input('project_id'),
        'message' => $request->input('message'),
    ]);

    return redirect()->back()->with('success', 'Спасибо за ваше пожертвование!');
}

}
