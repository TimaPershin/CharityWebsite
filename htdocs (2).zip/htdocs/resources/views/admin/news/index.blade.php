@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Список новостей</h2>

        <a href="{{ route('admin.news.create') }}" class="btn btn-success mb-3">Добавить новость</a>

        @if($news->isEmpty())
            <p>Новостей не найдено.</p>
        @else
            <table class="table">
                <thead>
                <tr>
                    <th>Заголовок</th>
                    <th>Дата создания</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                @foreach($news as $item)
                    <tr>
                        <td>{{ $item->title }}</td>
                        <td>{{ $item->created_at->format('d.m.Y H:i') }}</td>
                        <td>
                            <a href="{{ route('admin.news.edit', $item->id) }}" class="btn btn-primary btn-sm">Редактировать</a>

                            <form action="{{ route('admin.news.destroy', $item->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button onclick="return confirm('Удалить новость?')" class="btn btn-danger btn-sm">Удалить</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

            {{ $news->links() }}
        @endif
    </div>
@endsection
