@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Добавить проект</h2>

        <form method="POST" action="{{ route('admin.projects.store') }}">
        @csrf
            <div class="mb-3">
                <label>Название</label>
                <input type="text" name="title" class="form-control" required value="{{ old('title') }}">
                @error('title')<div class="text-danger">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label>Описание</label>
                <textarea name="description" class="form-control" required>{{ old('description') }}</textarea>
                @error('description')<div class="text-danger">{{ $message }}</div>@enderror
            </div>
            <button class="btn btn-primary">Создать</button>
            <a href="{{ route('admin.projects.index') }}" class="btn btn-secondary">Отмена</a>
        </form>
    </div>
@endsection
