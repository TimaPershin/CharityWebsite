@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Редактировать проект</h2>

        <form method="POST" action="{{ route('admin.projects.update', $project->id) }}">
        @csrf
            @method('PUT')
            <div class="mb-3">
                <label>Название</label>
                <input type="text" name="title" class="form-control" required value="{{ old('title', $project->title) }}">
                @error('title')<div class="text-danger">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label>Описание</label>
                <textarea name="description" class="form-control" required>{{ old('description', $project->description) }}</textarea>
                @error('description')<div class="text-danger">{{ $message }}</div>@enderror
            </div>
            <button class="btn btn-primary">Сохранить</button>
            <a href="{{ route('admin.projects.index') }}" class="btn btn-secondary">Отмена</a>
        </form>
    </div>
@endsection
