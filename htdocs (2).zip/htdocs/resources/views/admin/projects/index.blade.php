@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Список проектов</h2>

        <a href="{{ route('admin.projects.create') }}" class="btn btn-success mb-3">Добавить проект</a>

        @if($projects->isEmpty())
            <p>Проекты не найдены.</p>
        @else
            <table class="table">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Дата создания</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                @foreach($projects as $project)
                    <tr>
                        <td>{{ $project->title }}</td>
                        <td>{{ $project->created_at->format('d.m.Y H:i') }}</td>
                        <td>
                            <a href="{{ route('admin.projects.edit', $project->id) }}" class="btn btn-primary btn-sm">Редактировать</a>

                            <form action="{{ route('admin.projects.destroy', $project->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button onclick="return confirm('Удалить проект?')" class="btn btn-danger btn-sm">Удалить</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

            {{ $projects->links() }}
        @endif
    </div>
@endsection
