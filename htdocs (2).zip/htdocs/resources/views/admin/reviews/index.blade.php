@extends('layouts.app')

@section('content')
    <h2>Список отзывов</h2>

    @if($reviews->isEmpty())
        <p>Пока нет отзывов.</p>
    @else
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>Имя</th>
                <th>Сообщение</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($reviews as $review)
                <tr>
                    <td>{{ $review->user->name ?? '—' }}</td>
                    <td>{{ $review->content }}</td>
                    <td>{{ $review->created_at->format('d.m.Y H:i') }}</td>
                    <td>
                        <form method="POST" action="{{ route('admin.reviews.destroy', $review->id) }}">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Удалить отзыв?')">Удалить</button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @endif
@endsection
