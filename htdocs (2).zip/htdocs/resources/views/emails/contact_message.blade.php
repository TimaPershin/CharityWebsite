<h2>Новое сообщение с сайта Благотворительного фонда</h2>

<p><strong>Имя:</strong> {{ $data['name'] }}</p>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Сообщение:</strong><br> {{ $data['message'] }}</p>
