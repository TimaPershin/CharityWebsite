@extends('layouts.app')

@section('content')
    <div class="text-center">
        <h1>Добро пожаловать в Благотворительный фонд</h1>
        <p>Помогаем детям-сиротам, пожилым людям и развиваем образовательные программы.</p>
        <a href="{{ route('projects.index') }}" class="btn btn-primary">Посмотреть проекты</a>
    </div>
@endsection
