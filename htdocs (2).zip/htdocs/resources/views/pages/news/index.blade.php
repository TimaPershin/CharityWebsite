@extends('layouts.app')

@section('content')
    <h2>Новости</h2>

    @if($news->isEmpty())
        <p>Новостей пока нет.</p>
    @else
        <div class="list-group">
            @foreach($news as $item)
                <div class="list-group-item">
                    <h5>{{ $item->title }}</h5>
                    <p>{{ \Illuminate\Support\Str::limit($item->content, 200) }}</p>
                </div>
            @endforeach
        </div>
    @endif
@endsection
