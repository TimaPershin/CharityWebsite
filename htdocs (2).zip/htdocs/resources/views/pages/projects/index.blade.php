@extends('layouts.app')

@section('content')
    <h2>Наши проекты</h2>

    @if($projects->isEmpty())
        <p>Проекты пока не добавлены.</p>
    @else
        <div class="list-group">
            @foreach($projects as $project)
                <a href="{{ route('projects.show', $project->id) }}" class="list-group-item list-group-item-action">
                    <h5>{{ $project->title }}</h5>
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 150) }}</p>
                </a>
            @endforeach
        </div>
    @endif
@endsection
