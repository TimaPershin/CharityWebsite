@extends('layouts.app')

@section('content')
    <h2>{{ $project->title }}</h2>
    <p>{{ $project->description }}</p>

    <h4>Пожертвовать на этот проект</h4>

    @if(auth()->check())
        <form method="POST" action="{{ route('donations.store') }}">
            @csrf
            <input type="hidden" name="project_id" value="{{ $project->id }}">

            <div class="mb-3">
                <label>Сумма пожертвования (руб.)</label>
                <input type="number" name="amount" class="form-control" min="1" required>
            </div>

            <div class="mb-3">
                <label>Сообщение (необязательно)</label>
                <textarea name="message" class="form-control" rows="3"></textarea>
            </div>

            <button class="btn btn-success" type="submit">Пожертвовать</button>
        </form>
    @else
        <p>Пожалуйста, <a href="{{ route('login') }}">войдите</a> чтобы сделать пожертвование.</p>
    @endif
@endsection
