@extends('layouts.app')

@section('content')
    <h2>Отзывы</h2>

    @if($reviews->isEmpty())
        <p>Пока нет отзывов.</p>
    @else
        @foreach($reviews as $review)
            <div class="border rounded p-3 mb-3">
                <strong>{{ $review->user->name }}</strong> написал(а):
                <p>{{ $review->content }}</p>
            </div>
        @endforeach
    @endif

    @auth
        <h4>Оставить отзыв</h4>
        <form method="POST" action="{{ route('reviews.store') }}">
            @csrf
            <div class="mb-3">
                <textarea name="content" rows="3" class="form-control" required></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Отправить</button>
        </form>
    @else
        <p>Чтобы оставить отзыв, пожалуйста, <a href="{{ route('login') }}">войдите</a>.</p>
    @endauth

@endsection
