<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\DonationController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AuthController;
use App\Models\Project;
use App\Models\News;
use App\Models\Review;

// Главная
Route::get('/', function () {
    return view('home');
})->name('home');

// Аутентификация
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Проекты
Route::get('/projects', [ProjectController::class, 'index'])->name('projects.index');

// Пожертвования
Route::post('/donations', [DonationController::class, 'store'])->name('donations.store')->middleware('auth');

// Новости
Route::get('/news', [NewsController::class, 'index'])->name('news.index');

// Отзывы
Route::get('/reviews', [ReviewController::class, 'index'])->name('reviews.index');
Route::post('/reviews', [ReviewController::class, 'store'])->middleware('auth')->name('reviews.store');

// Контакты
Route::get('/contacts', [ContactController::class, 'create'])->name('contacts.create');
Route::post('/contacts', [ContactController::class, 'store'])->name('contacts.store');

Route::get('/projects/{project}', [ProjectController::class, 'show'])->name('projects.show');
Route::resource('projects', ProjectController::class)->only(['index', 'show']);

Route::view('/about', 'pages.about')->name('about');
Route::view('/sponsors', 'pages.sponsors')->name('sponsors');

// Админка
Route::middleware(['auth', 'admin'])->name('admin.')->group(function () {

    Route::get('/admin/projects', [ProjectController::class, 'adminIndex'])->name('projects.index');
    Route::resource('/admin/projects', ProjectController::class)->except(['index']);

    Route::get('/admin/news', [NewsController::class, 'adminIndex'])->name('news.index');
    Route::resource('/admin/news', NewsController::class)->except(['index']);

    Route::get('/admin/reviews', function () {
        $reviews = Review::latest()->with('user')->get();
        return view('admin.reviews.index', compact('reviews'));
    })->name('reviews.index');

    Route::delete('/admin/reviews/{id}', [ReviewController::class, 'destroy'])->name('reviews.destroy');
});



