<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Список проектов</h2>

        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-success mb-3">Добавить проект</a>

        <?php if($projects->isEmpty()): ?>
            <p>Проекты не найдены.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Дата создания</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($project->title); ?></td>
                        <td><?php echo e($project->created_at->format('d.m.Y H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.projects.edit', $project->id)); ?>" class="btn btn-primary btn-sm">Редактировать</a>

                            <form action="<?php echo e(route('admin.projects.destroy', $project->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Удалить проект?')" class="btn btn-danger btn-sm">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($projects->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>