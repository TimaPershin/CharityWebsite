<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Благотворительный фонд</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Благотворительный фонд</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Переключить навигацию">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about')); ?>">О нас</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('sponsors')); ?>">Спонсоры</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('projects.index')); ?>">Проекты</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('news.index')); ?>">Новости</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reviews.index')); ?>">Отзывы</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contacts.create')); ?>">Контакты</a></li>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Войти</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Регистрация</a></li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="userDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                           data-bs-toggle="dropdown" aria-expanded="false" style="cursor: pointer;">
                            
                            <?php if(auth()->user()->is_admin): ?>
                                Админ:
                            <?php else: ?>
                                Пользователь:
                            <?php endif; ?>
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <?php if(auth()->user()->is_admin): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.projects.index')); ?>">Управление проектами</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.news.index')); ?>">Управление новостями</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.reviews.index')); ?>">Управление отзывами</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Выйти</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/layouts/app.blade.php ENDPATH**/ ?>