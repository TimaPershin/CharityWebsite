<?php $__env->startSection('content'); ?>
    <h2><?php echo e($project->title); ?></h2>
    <p><?php echo e($project->description); ?></p>

    <h4>Пожертвовать на этот проект</h4>

    <?php if(auth()->check()): ?>
        <form method="POST" action="<?php echo e(route('donations.store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">

            <div class="mb-3">
                <label>Сумма пожертвования (руб.)</label>
                <input type="number" name="amount" class="form-control" min="1" required>
            </div>

            <div class="mb-3">
                <label>Сообщение (необязательно)</label>
                <textarea name="message" class="form-control" rows="3"></textarea>
            </div>

            <button class="btn btn-success" type="submit">Пожертвовать</button>
        </form>
    <?php else: ?>
        <p>Пожалуйста, <a href="<?php echo e(route('login')); ?>">войдите</a> чтобы сделать пожертвование.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/projects/show.blade.php ENDPATH**/ ?>