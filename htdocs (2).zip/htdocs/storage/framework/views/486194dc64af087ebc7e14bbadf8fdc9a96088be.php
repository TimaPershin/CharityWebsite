<?php $__env->startSection('content'); ?>
    <h2>Спонсоры</h2>
    <p>Наши спонсоры – это компании и частные лица, которые помогают нам осуществлять миссию.</p>
    <ul>
        <li>Компания А</li>
        <li>Компания Б</li>
        <li>Компания В</li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/sponsors.blade.php ENDPATH**/ ?>