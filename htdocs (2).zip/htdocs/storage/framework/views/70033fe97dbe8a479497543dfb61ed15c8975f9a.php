<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row mb-4">
            <div class="col-md-6">
                <h2>Контактная информация</h2>
                <div class="mt-4">
                    <p><strong>Адрес:</strong> г. Северодвинск, ул. Капитана Воронина, д 6</p>
                    <p><strong>Телефон:</strong> +7 (818) 453-95-67</p>
                    <p><strong>Email:</strong> test@gmail.com</p>
                </div>
            </div>
            <div class="col-md-6">
                <h2>Наше местоположение</h2>
                <div class="ratio ratio-4x3">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7753.176007999935!2d39.819693999999995!3d64.56536059999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x443eedfdedb7033d%3A0x6edb4cbe3b91e616!2z0YPQuy4g0JrRgNC40LrQvtCy0LAg0J_RgNC-0LzQsNGF0L7QstCwLCA2LCDQn9C-0LvQvtCz0YDQsNC00YHQutCw0Y8sINCS0LjQt9Cy0LDRjywgMTYwMDAz!5e0!3m2!1sru!2sru!4v1716394200000!5m2!1sru!2sru"
                        width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>
        </div>

        <div class="text-center mb-4">
            <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#contactForm"
                    aria-expanded="false" aria-controls="contactForm">
                Свяжитесь с нами
            </button>
        </div>

        <div class="collapse" id="contactForm">
            <div class="card card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('contacts.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="name" class="form-label">Имя</label>
                        <input type="text" name="name" required id="name"
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Электронная почта</label>
                        <input type="email" name="email" required id="email"
                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="message" class="form-label">Сообщение</label>
                        <textarea name="message" id="message" required rows="5"
                                  class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('message')); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Отправить</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/contacts/create.blade.php ENDPATH**/ ?>