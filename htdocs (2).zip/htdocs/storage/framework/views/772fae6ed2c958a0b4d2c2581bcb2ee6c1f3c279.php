<?php $__env->startSection('content'); ?>
    <h2>Новости</h2>

    <?php if($news->isEmpty()): ?>
        <p>Новостей пока нет.</p>
    <?php else: ?>
        <div class="list-group">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                    <h5><?php echo e($item->title); ?></h5>
                    <p><?php echo e(\Illuminate\Support\Str::limit($item->content, 200)); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/news/index.blade.php ENDPATH**/ ?>