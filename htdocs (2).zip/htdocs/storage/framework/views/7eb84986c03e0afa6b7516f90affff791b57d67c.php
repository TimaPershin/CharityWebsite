<h2>Новое сообщение с сайта Благотворительного фонда</h2>

<p><strong>Имя:</strong> <?php echo e($data['name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Сообщение:</strong><br> <?php echo e($data['message']); ?></p>
<?php /**PATH C:\xampp\htdocs\resources\views/emails/contact_message.blade.php ENDPATH**/ ?>