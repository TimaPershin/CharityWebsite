<?php $__env->startSection('content'); ?>
    <h2>Наши проекты</h2>

    <?php if($projects->isEmpty()): ?>
        <p>Проекты пока не добавлены.</p>
    <?php else: ?>
        <div class="list-group">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="list-group-item list-group-item-action">
                    <h5><?php echo e($project->title); ?></h5>
                    <p><?php echo e(\Illuminate\Support\Str::limit($project->description, 150)); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/projects/index.blade.php ENDPATH**/ ?>