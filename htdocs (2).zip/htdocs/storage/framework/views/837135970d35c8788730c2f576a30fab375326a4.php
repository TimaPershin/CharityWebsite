<?php $__env->startSection('content'); ?>
    <h2>О нас</h2>
    <p>Мы – благотворительный фонд, который помогает детям-сиротам, пожилым людям и поддерживает образовательные программы.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/about.blade.php ENDPATH**/ ?>