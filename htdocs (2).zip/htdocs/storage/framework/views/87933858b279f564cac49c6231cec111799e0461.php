<?php $__env->startSection('content'); ?>
    <h2>Отзывы</h2>

    <?php if($reviews->isEmpty()): ?>
        <p>Пока нет отзывов.</p>
    <?php else: ?>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded p-3 mb-3">
                <strong><?php echo e($review->user->name); ?></strong> написал(а):
                <p><?php echo e($review->content); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <h4>Оставить отзыв</h4>
        <form method="POST" action="<?php echo e(route('reviews.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <textarea name="content" rows="3" class="form-control" required></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Отправить</button>
        </form>
    <?php else: ?>
        <p>Чтобы оставить отзыв, пожалуйста, <a href="<?php echo e(route('login')); ?>">войдите</a>.</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/reviews/index.blade.php ENDPATH**/ ?>