<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Список новостей</h2>

        <a href="<?php echo e(route('admin.news.create')); ?>" class="btn btn-success mb-3">Добавить новость</a>

        <?php if($news->isEmpty()): ?>
            <p>Новостей не найдено.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Заголовок</th>
                    <th>Дата создания</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->created_at->format('d.m.Y H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.news.edit', $item->id)); ?>" class="btn btn-primary btn-sm">Редактировать</a>

                            <form action="<?php echo e(route('admin.news.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Удалить новость?')" class="btn btn-danger btn-sm">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($news->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/admin/news/index.blade.php ENDPATH**/ ?>