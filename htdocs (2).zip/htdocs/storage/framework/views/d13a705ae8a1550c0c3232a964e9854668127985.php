<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1>Добро пожаловать в Благотворительный фонд</h1>
        <p>Помогаем детям-сиротам, пожилым людям и развиваем образовательные программы.</p>
        <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-primary">Посмотреть проекты</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/home.blade.php ENDPATH**/ ?>